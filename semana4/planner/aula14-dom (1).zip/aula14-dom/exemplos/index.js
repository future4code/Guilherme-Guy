function passouOMousePorCima() {
    console.log("Passou o mouse por cima!")
}

function tirouOMouseDeCima() {
    console.log("Tirou o mouse!")
}